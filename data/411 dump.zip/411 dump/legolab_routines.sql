-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: legolab
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'legolab'
--
/*!50003 DROP PROCEDURE IF EXISTS `GetActiveBuild` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetActiveBuild`(
    IN p_user_id VARCHAR(100)
)
BEGIN
    DECLARE v_active_build_id VARCHAR(100);

    -- Get the active build ID for the user
    SELECT current_build_id INTO v_active_build_id
    FROM USERS
    WHERE user_id = p_user_id;

    -- If no active build is set, prepare empty results
    IF v_active_build_id IS NULL THEN
        -- Return an empty build details result
        SELECT 
            NULL AS build_id, 
            NULL AS build_name, 
            NULL AS build_description, 
            NULL AS build_image;
        
        -- Return empty owned parts
        SELECT 
            NULL AS part_id, 
            NULL AS part_color, 
            0 AS required_quantity, 
            0 AS user_quantity;

        -- Return empty missing parts
        SELECT 
            NULL AS part_id, 
            NULL AS part_color, 
            0 AS missing_quantity, 
            0.00 AS lowest_price;

        -- Return total cost as zero
        SELECT 0.00 AS total_cost;

    ELSE
        -- Fetch build details
        SELECT 
            b.build_id,
            b.build_name,
            b.build_png AS build_image,
            b.build_link AS build_description
        FROM BUILDS b
        WHERE b.build_id = v_active_build_id;

        -- Fetch parts required for the active build
        CREATE TEMPORARY TABLE TempBuildParts AS
        SELECT 
            bd.part_id,
            bd.part_color,
            bd.part_quantity AS required_quantity,
            COALESCE(inv.part_quantity, 0) AS user_quantity,
            GREATEST(0, bd.part_quantity - COALESCE(inv.part_quantity, 0)) AS missing_quantity
        FROM BUILD_DETAILS bd
        LEFT JOIN INVENTORY inv 
            ON bd.part_id = inv.part_id 
            AND bd.part_color = inv.part_color 
            AND inv.user_id = p_user_id
        WHERE bd.build_id = v_active_build_id;

        -- Fetch missing parts with lowest price
        CREATE TEMPORARY TABLE TempMissingParts AS
        SELECT 
            tbp.part_id,
            tbp.part_color,
            tbp.missing_quantity,
            MIN(pp.part_price) AS lowest_price
        FROM TempBuildParts tbp
        LEFT JOIN PART_PRICING pp 
            ON tbp.part_id = pp.part_id 
            AND tbp.part_color = pp.part_color
        WHERE tbp.missing_quantity > 0
        GROUP BY tbp.part_id, tbp.part_color;

        -- Calculate total cost
        SELECT SUM(mp.missing_quantity * mp.lowest_price) INTO @total_cost
        FROM TempMissingParts mp;

        -- Return user-owned parts
        SELECT 
            tbp.part_id,
            tbp.part_color,
            tbp.required_quantity,
            tbp.user_quantity
        FROM TempBuildParts tbp
        WHERE tbp.missing_quantity = 0;

        -- Return missing parts
        SELECT 
            mp.part_id,
            mp.part_color,
            mp.missing_quantity,
            mp.lowest_price
        FROM TempMissingParts mp;

        -- Return total cost
        SELECT @total_cost AS total_cost;

        -- Cleanup temporary tables
        DROP TEMPORARY TABLE TempBuildParts;
        DROP TEMPORARY TABLE TempMissingParts;

    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetActiveBuildDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetActiveBuildDetails`(
    IN p_user_id VARCHAR(100)
)
BEGIN
    DECLARE v_active_build_id VARCHAR(100);

    -- Get the active build ID for the user
    SELECT active_build_id INTO v_active_build_id
    FROM USERS
    WHERE user_id = p_user_id;

    -- If no active build is set, prepare empty results
    IF v_active_build_id IS NULL THEN
        -- Return an empty build details result
        SELECT 
            NULL AS build_id, 
            NULL AS build_name, 
            NULL AS build_description, 
            NULL AS build_image;
        
        -- Return empty owned parts
        SELECT 
            NULL AS part_id, 
            NULL AS part_color, 
            0 AS required_quantity, 
            0 AS user_quantity;

        -- Return empty missing parts
        SELECT 
            NULL AS part_id, 
            NULL AS part_color, 
            0 AS missing_quantity, 
            0.00 AS lowest_price;

        -- Return total cost as zero
        SELECT 0.00 AS total_cost;

    ELSE
        -- Fetch build details
        SELECT 
            b.build_id,
            b.build_name,
            b.build_png AS build_image,
            b.build_link AS build_description
        FROM BUILDS b
        WHERE b.build_id = v_active_build_id;

        -- Fetch parts required for the active build
        CREATE TEMPORARY TABLE TempBuildParts AS
        SELECT 
            bd.part_id,
            bd.part_color,
            bd.part_quantity AS required_quantity,
            COALESCE(inv.part_quantity, 0) AS user_quantity,
            GREATEST(0, bd.part_quantity - COALESCE(inv.part_quantity, 0)) AS missing_quantity
        FROM BUILD_DETAILS bd
        LEFT JOIN INVENTORY inv 
            ON bd.part_id = inv.part_id 
            AND bd.part_color = inv.part_color 
            AND inv.user_id = p_user_id
        WHERE bd.build_id = v_active_build_id;

        -- Fetch missing parts with lowest price
        CREATE TEMPORARY TABLE TempMissingParts AS
        SELECT 
            tbp.part_id,
            tbp.part_color,
            tbp.missing_quantity,
            MIN(pp.part_price) AS lowest_price
        FROM TempBuildParts tbp
        LEFT JOIN PART_PRICING pp 
            ON tbp.part_id = pp.part_id 
            AND tbp.part_color = pp.part_color
        WHERE tbp.missing_quantity > 0
        GROUP BY tbp.part_id, tbp.part_color;

        -- Calculate total cost
        SELECT SUM(mp.missing_quantity * mp.lowest_price) INTO @total_cost
        FROM TempMissingParts mp;

        -- Return user-owned parts
        SELECT 
            tbp.part_id,
            tbp.part_color,
            tbp.required_quantity,
            tbp.user_quantity
        FROM TempBuildParts tbp
        WHERE tbp.missing_quantity = 0;

        -- Return missing parts
        SELECT 
            mp.part_id,
            mp.part_color,
            mp.missing_quantity,
            mp.lowest_price
        FROM TempMissingParts mp;

        -- Return total cost
        SELECT @total_cost AS total_cost;

        -- Cleanup temporary tables
        DROP TEMPORARY TABLE TempBuildParts;
        DROP TEMPORARY TABLE TempMissingParts;

    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetBuildDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetBuildDetails`(
    IN user_id_param VARCHAR(100)
)
BEGIN
    -- Declare variables
    DECLARE active_build_id VARCHAR(100);

    -- Step 1: Get the active build ID for the user
    SELECT current_build_id INTO active_build_id
    FROM users
    WHERE user_id = user_id_param;

    -- Step 2: Fetch build details
    SELECT 
        b.build_id,
        b.build_name,
        b.build_png,
        b.build_link,
        b.build_age_rating,
        b.build_rating,
        b.build_release_year
    FROM builds b
    WHERE b.build_id = active_build_id;

    -- Step 3: Fetch parts required for the active build
    SELECT 
        bd.part_id,
        bd.part_color,
        bd.part_quantity AS required_quantity,
        p.part_name,
        p.part_color
    FROM build_details bd
    INNER JOIN parts p ON bd.part_id = p.part_id AND bd.part_color = p.part_color
    WHERE bd.build_id = active_build_id;

    -- Step 4: Fetch the user's inventory for the required parts
    SELECT 
		p.part_name,
        p.part_png,
        p.part_dimensions,
        i.part_id,
        i.part_color,
        i.part_quantity AS user_quantity
    FROM inventory i
    JOIN Parts p ON p.part_id = i.part_id AND p.part_color = i.part_color
    WHERE i.user_id = user_id_param
    AND EXISTS (
        SELECT 1 
        FROM build_details bd 
        WHERE bd.build_id = active_build_id 
        AND bd.part_id = i.part_id 
        AND bd.part_color = i.part_color
    );

    -- Step 5: Fetch missing parts and lowest prices
    SELECT 
        bd.part_id,
        bd.part_color,
        bd.part_quantity AS required_quantity,
        p.part_name,
        p.part_color,
        p.part_png, 
        p.part_dimensions,
        COALESCE(MIN(pp.part_price), 0) AS lowest_price
    FROM build_details bd
    INNER JOIN parts p ON bd.part_id = p.part_id AND bd.part_color = p.part_color
    LEFT JOIN part_pricing pp ON pp.part_id = bd.part_id AND pp.part_color = bd.part_color
    WHERE bd.build_id = active_build_id
    AND NOT EXISTS (
        SELECT 1 
        FROM inventory i 
        WHERE i.user_id = user_id_param 
        AND i.part_id = bd.part_id 
        AND i.part_color = bd.part_color
        AND i.part_quantity >= bd.part_quantity
    )
    GROUP BY bd.part_id, bd.part_color, bd.part_quantity, p.part_name, p.part_color;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetCurrBuildDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCurrBuildDetails`(
    IN p_user_id VARCHAR(100)
)
BEGIN
    DECLARE v_active_build_id VARCHAR(100);

    -- Get the active build ID for the user
    SELECT current_build_id INTO v_active_build_id
    FROM USERS
    WHERE user_id = p_user_id;

    -- If no active build is set, prepare empty results
    IF v_active_build_id IS NULL THEN
        -- Return an empty build details result
        SELECT 
            NULL AS build_id, 
            NULL AS build_name, 
            NULL AS build_description, 
            NULL AS build_image;
        
        -- Return empty owned parts
        SELECT 
            NULL AS part_id, 
            NULL AS part_color, 
            0 AS required_quantity, 
            0 AS user_quantity;

        -- Return empty missing parts
        SELECT 
            NULL AS part_id, 
            NULL AS part_color, 
            0 AS missing_quantity, 
            0.00 AS lowest_price;

        -- Return total cost as zero
        SELECT 0.00 AS total_cost;

    ELSE
        -- Fetch build details
        SELECT 
            b.build_id,
            b.build_name,
            b.build_png AS build_image,
            b.build_link AS build_description
        FROM BUILDS b
        WHERE b.build_id = v_active_build_id;

        -- Fetch parts required for the active build
        CREATE TEMPORARY TABLE TempBuildParts AS
        SELECT 
            bd.part_id,
            bd.part_color,
            bd.part_quantity AS required_quantity,
            COALESCE(inv.part_quantity, 0) AS user_quantity,
            GREATEST(0, bd.part_quantity - COALESCE(inv.part_quantity, 0)) AS missing_quantity
        FROM BUILD_DETAILS bd
        LEFT JOIN INVENTORY inv 
            ON bd.part_id = inv.part_id 
            AND bd.part_color = inv.part_color 
            AND inv.user_id = p_user_id
        WHERE bd.build_id = v_active_build_id;

        -- Fetch missing parts with lowest price
        CREATE TEMPORARY TABLE TempMissingParts AS
        SELECT 
            tbp.part_id,
            tbp.part_color,
            tbp.missing_quantity,
            MIN(pp.part_price) AS lowest_price
        FROM TempBuildParts tbp
        LEFT JOIN PART_PRICING pp 
            ON tbp.part_id = pp.part_id 
            AND tbp.part_color = pp.part_color
        WHERE tbp.missing_quantity > 0
        GROUP BY tbp.part_id, tbp.part_color, tbp.missing_quantity;

        -- Calculate total cost
        SELECT SUM(mp.missing_quantity * mp.lowest_price) INTO @total_cost
        FROM TempMissingParts mp;

        -- Return user-owned parts
        SELECT 
            tbp.part_id,
            tbp.part_color,
            tbp.required_quantity,
            tbp.user_quantity
        FROM TempBuildParts tbp
        WHERE tbp.missing_quantity = 0;

        -- Return missing parts
        SELECT 
            mp.part_id,
            mp.part_color,
            mp.missing_quantity,
            mp.lowest_price
        FROM TempMissingParts mp;

        -- Return total cost
        SELECT @total_cost AS total_cost;

        -- Cleanup temporary tables
        DROP TEMPORARY TABLE TempBuildParts;
        DROP TEMPORARY TABLE TempMissingParts;

    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetMostFrequentParts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetMostFrequentParts`()
BEGIN
    SELECT DISTINCT lp.part_id, lp.part_name, SUM(bd.part_quantity) AS total_quantity_used
    FROM PARTS AS lp
    JOIN BUILD_DETAILS AS bd ON lp.part_id = bd.part_id
    GROUP BY lp.part_id, lp.part_name
    ORDER BY total_quantity_used DESC, lp.part_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-08 23:53:43
