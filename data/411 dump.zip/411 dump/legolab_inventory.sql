-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: legolab
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `user_id` varchar(100) NOT NULL,
  `part_id` varchar(100) NOT NULL,
  `part_color` varchar(100) NOT NULL,
  `part_quantity` int DEFAULT NULL,
  PRIMARY KEY (`user_id`,`part_id`,`part_color`),
  KEY `part_id` (`part_id`,`part_color`),
  CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`part_id`, `part_color`) REFERENCES `parts` (`part_id`, `part_color`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES ('1','01598pr0001','Dark Tan',1),('1','01648pr0001','White',5),('1','01889pr0001','Light Nougat',5),('1','1','Blue',8),('1','10000','Violet',1),('1','10051pr0001','Pearl Titanium',1),('1','10069000','[No Color/Any Color]',10),('1','1022Apr0010','Modulex White',11),('1','3069bpr0254','Trans-Clear',12),('800512a0-b5da-11ef-92bc-a05950561075','01598pr0001','Dark Tan',1),('800512a0-b5da-11ef-92bc-a05950561075','01920pr0001','Dark Orange',10),('800512a0-b5da-11ef-92bc-a05950561075','10172','Pearl Gold',100),('800512a0-b5da-11ef-92bc-a05950561075','11153','Black',10),('800512a0-b5da-11ef-92bc-a05950561075','11153','Red',3),('800512a0-b5da-11ef-92bc-a05950561075','13547','White',10),('800512a0-b5da-11ef-92bc-a05950561075','4jfig0010','Red',17),('965b7361-b554-11ef-92bc-a05950561075','10000','Violet',4),('965b7361-b554-11ef-92bc-a05950561075','10001119','[No Color/Any Color]',5),('a828e397-b53e-11ef-92bc-a05950561075','01889pr0001','Light Nougat',15),('a828e397-b53e-11ef-92bc-a05950561075','3626cpr2112','Blue',5),('c625e298-b5cd-11ef-92bc-a05950561075','01598pr0001','Dark Tan',4),('c625e298-b5cd-11ef-92bc-a05950561075','01642pr0001','Dark Tan',4),('c625e298-b5cd-11ef-92bc-a05950561075','0687b1','[No Color/Any Color]',1);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-08 23:53:41
