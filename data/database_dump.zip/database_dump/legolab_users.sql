CREATE DATABASE  IF NOT EXISTS `legolab` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `legolab`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: legolab
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_age` int DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1','aryan10','password','aryan10@illinois.edu',20),('47e42ef8-a5e2-11ef-a099-a05950561075','1','$2b$10$WfQU8ZELhMat12krq4auLuGz0hPZfj4UM/MdRX8EMluUdkvTt4KJK','1@1',1),('47e53354-a5e2-11ef-a099-a05950561075','1','$2b$10$bhYU2RcZM9OoRXgIBcEKgOr7peeclUsaGpjgJkO026YaznbdM0Qha','1@1',1),('47e6bd0b-a5e2-11ef-a099-a05950561075','1','$2b$10$Sm80GbVUK.BLNvGss2fqaemPh.sdl5NyYENTov12weNbz0tgaEj4u','1@1',1),('47e6ff1a-a5e2-11ef-a099-a05950561075','1','$2b$10$shNLMf3RzmDsDJdczh6wV.llZQ2wOdkkYawNrjBLLe/4Gqv.u3kFK','1@1',1),('481223bc-a5e2-11ef-a099-a05950561075','1','$2b$10$8dAbyVDXF63hyTdpATLe4uwhfj84qFXlCFidjw8vsVdUwl1Xfm9BC','1@1',1),('48132292-a5e2-11ef-a099-a05950561075','1','$2b$10$E7rIdpHSHa1jc.qO1uNYSepMS239phv1l362ue.r.FR/5FtdiEari','1@1',1),('59f66bdd-a5e2-11ef-a099-a05950561075','1','$2b$10$IXS5TPm5lVfBDSJi/jd1Lu0/2EIpbMzcPSn5jMKk68LKu9JxrzWoy','1@1',1),('59f7fb74-a5e2-11ef-a099-a05950561075','1','$2b$10$yNG.YjU4CN8qC3HhgrpCJurWWC87jRkpGFesUSG/vOkJfZfkhmVlu','1@1',1),('59f8fc66-a5e2-11ef-a099-a05950561075','1','$2b$10$3xMyDN8kD5le6iU/gq7xzOOiKVkvnUoe9gUXxCVy/nYKGqDYeOlDK','1@1',1),('59f957b6-a5e2-11ef-a099-a05950561075','1','$2b$10$n8rsgOVmbz792t/nWu1XY.SS908qqhXkt0RBsdlLHFqF0iJstygdu','1@1',1),('5a056ae0-a5e2-11ef-a099-a05950561075','1','$2b$10$H60O8uupTjytlbJUeXYDDeC1IIDrR4QMUqytrxY73aNzW9VSUcnOq','1@1',1),('5a074e9e-a5e2-11ef-a099-a05950561075','1','$2b$10$CXh0ZDv4.JrdqekOR8a.y.SQ8Fwb5apjk8bT/7TBtWE3c5pgL6N2G','1@1',1),('6a6ba9f6-a5e2-11ef-a099-a05950561075','1','$2b$10$6V.1CvozOK5tTsB2SzcukuRjVRe.Fy4xc9SNZse47/pZqLnnSTJzi','1@1',1),('8049a664-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$GnMHituZhNP9XKr30P4BfeC6yhMobJWzakQ845O/pDLuj1OwFe.3a','guptaaryan1405@gmail.com',20),('82c8a288-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$W3I15gCHNtkCS5fGd4l3mumhEiRMAsB/oPAdSzMp9yJ/so6BRQnMm','guptaaryan1405@gmail.com',20),('91273f79-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$FclAL4FT4RumFmYL.kHJu.R2GRkf3JlOMx.61HThfVidFzqvlfP5K','guptaaryan1405@gmail.com',20),('969a587d-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$hukJvazUkd5CsbhqUaXgLObm13fT7xJoLXpcbxf/q4njZ.Gi.s64.','guptaaryan1405@gmail.com',20),('96f84ff7-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$iTpH5Jreb4V5rKi4sChNqOmC5y/me6EwC9Y4SefGZGMSweqG5h2CC','guptaaryan1405@gmail.com',20),('9714365f-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$5KB.Q8asKkq1DisJDj4z1egouOoq50y5idqZzNX0HWSxKbU9RJ.3q','guptaaryan1405@gmail.com',20),('9732ec7c-a5e1-11ef-a099-a05950561075','Flash1405','$2b$10$5v8oQ5GInolQgqDPdtyeXO3g2GRb2dbH85Rq39qnaIz.ZYYlx3eKC','guptaaryan1405@gmail.com',20),('e46fa47e-a5e1-11ef-a099-a05950561075','1','$2b$10$WNTG.75l5HPzC03sEAsTw.fXiZTE5XMjinFU4ku95eoQJpB481rnu','1@1',1),('e4bc5322-a5e1-11ef-a099-a05950561075','1','$2b$10$pbJyOq4uYLN2ChoB7v6IxOYoTE9PDiwPYQ66Hb1lCB.11jr.Wlzga','1@1',1),('e51553a0-a5e1-11ef-a099-a05950561075','1','$2b$10$yGkGlmd8MOe8O0Q99FjVwOPTlzBFWczFi6VnDz/lot1yb1fyPW.g.','1@1',1),('e52eb033-a5e1-11ef-a099-a05950561075','1','$2b$10$sQ6Ng5W.lij3wo/M37BS9uJaOnPJ0ND9p0WXL44vV8TLTbfDCB8IS','1@1',1),('e5487d43-a5e1-11ef-a099-a05950561075','1','$2b$10$AmCiZMfrGv.qB2PUbjGXWupnnZE./wgx/Jd5wVIS/uIlMuqM6SVeK','1@1',1),('e5623dab-a5e1-11ef-a099-a05950561075','1','$2b$10$fyjFemhG1pBEYMbRBUqnvuCOx/xxjwwhCGzglrATFMKU8YiA.FyAO','1@1',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 22:53:47
